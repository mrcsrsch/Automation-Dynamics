# facet_grid2 warns about inappropriate arguments

    x cannot be independent if scales are not free.

---

    y cannot be independent if scales are not free.

---

    x cannot have free space if axes are independent.
    i Overriding `space` for x to "FALSE".

---

    y cannot have free space if axes are independent.
    i Overriding `space` for y to "FALSE".

---

    x-axes must be labelled if they are independent.
    i Overriding `remove_labels` for x to "FALSE".

---

    y-axes must be labelled if they are independent.
    i Overriding `remove_labels` for y to "FALSE".

