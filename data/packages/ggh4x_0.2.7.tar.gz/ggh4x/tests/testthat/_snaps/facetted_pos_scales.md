# facetted_pos_scales warns about invalid scales

    The `x` argument should be "NULL", or a list of formulas and/or position scales with the x aesthetic.

---

    The `y` argument should be "NULL", or a list of formulas and/or position scales with the y aesthetic.

# facetted_pos_scales warns about invalid scales in formulas

    The right-hand side of formula does not result in an appropriate scale.

# facetted_pos_scales warns about unusual facets

    Unknown facet: a <TestFacet/FacetGrid/Facet/ggproto/gg> object.
    i Overriding facetted scales may be unstable.

