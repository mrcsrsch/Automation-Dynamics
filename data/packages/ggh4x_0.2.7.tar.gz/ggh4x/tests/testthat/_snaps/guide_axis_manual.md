# warnings and errors work

    operator '<' not meaningful for units

---

    axis guide needs appropriate scales.

